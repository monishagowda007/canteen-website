<<?php 
include 'header.php'
?>
 <!-- Main Content -->
    <main class="main-wrap">
        <div class="theme-padding">
            <div class="container">

                <div class="row mb-30">

                    <!-- contact holder -->
                    <div class="col-md-12">

                        <!-- Heading -->
                                  <nav class="navbar navbar-light bg-warning">
        <a class="navbar-brand" >
          Student Union
      </a>
    </nav> <br><br><br>
                       

                        <div style="font-weight: bold; ">
                            <p>Names of Office Bearers :</p>
                            <ol>
                                <li>Sri Sunil Murmu - President</li>
                                <li>Sri Diwakar Mandal - Vice President</li>
                                <li>Sri Vikram Kumar Paswan - Secretary</li>
                                <li>Smt. Reena Soren - Joint Secretary</li>
                                <li>Sri Umesh Kumar Mandal - Deputy Secretary</li>
                                <li>Sri Ghanshyam Yadav - University Representative</li>
                            </ol>
                        </div>

                    </div>
                </div>


            </div>
        </div>
    </main>
    

<<?php 
include 'footer.php'
 ?>