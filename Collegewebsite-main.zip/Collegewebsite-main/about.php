<?php
include 'header.php';
?>
    <!--====== HEADER PART ENDS ======-->
   
    <!--====== SEARCH BOX PART START ======-->
    
    <div class="search-box">
        <div class="serach-form">
            <div class="closebtn">
                <span></span>
                <span></span>
            </div>
            <form action="#">
                <input type="text" placeholder="Search by keyword">
                <button><i class="fa fa-search"></i></button>
            </form>
        </div> <!-- serach form -->
    </div>
    
   

<div style="background-color: #52ccd4 ; padding-top: 5px;
    padding-bottom: 5px;" > 

    <div style="background-color: Black ; padding-top: 0px;
    padding-bottom: 5px;" > 

     <h3 style="color:white" align="center"> About us</h3>
 </div>

    <section id="about-page" class="pt-70 pb-110">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="section-title mt-50">
                      
                        <h2>Welcome to Sahibganj College</h2>
                    </div> <!-- section title -->
                    <div class="about-cont">
 <p>Sahibganj College is one of the premier constituent college of S.K.M.University Dumka (Jharkhand). 
 The district of Sahibganj is situated approximately between 240 42’ north and 250 21’ north latitude and between  87 25’ and 87 54’ east longitude. Sahibganj is the administrative headquarter of the district.     It is situated on the bank of the river Ganges at 25 15’ latitude and 87O 25’ longitude .
 The College has an area of 29 Bigha 16 Katha 9 Dhur(10 Acre appx.) The college was established in the year 1951 . It is one of the reputed college of the university as well as the Jharkhand state. It is imparting education from  Degree to PG level. Besides this, there is also provision for teaching in B.Ed., BCA. In 2002 IGNOU center was 
  established in this campus. In 2006 B.Ed. teaching was established in this college. While BCA was started in 2009.Now,the college has started teaching in BBA, Library & Information Sciences , Certificate as well as Diploma courses in Computer Science.  </p>
                    </div>
                </div> <!-- about cont -->
                <div class="col-lg-7">
                    <div class="about-image mt-50">
                        <img src="images/about/q.jpeg" alt="About">
                    </div>  <!-- about imag -->
                </div> 
            </div> <!-- row -->
            
            </div> <!-- about items -->
        </div> <!-- container -->
    </section>
    <?php
include 'footer.php';
?>
