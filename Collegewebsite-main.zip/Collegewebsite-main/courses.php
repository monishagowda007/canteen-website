<?php
include 'header.php';
?>
   
   <main class="main-wrap">
          <div class="container">
        <div class="theme-padding">
             <div class="primary-heading">
                    <h2 style="">Courses</h2>
                </div>
            <div class="container">
                <h3 style="color:#205495;">A. Three year Degree programmes in B.A. / B.Sc. / B.Com.</h3>
                <div class="row table-responsive">
                    <table class="table">
    <thead>
      <tr>
        <th>Sl.No.</th>
        <th>Faculty</th>
        <th>Title of the Courses</th>
       
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>HUMANITIES</td>
        <td>B.A. Hons. in English</td>
      
      </tr>
         <tr>
        <td>2</td>
        <td></td>
        <td>B.A. Hons. in Hindi</td>
      
      </tr>
         <tr>
        <td>3</td>
        <td></td>
        <td>B.A. Hons. in Sanskrit</td>
      
      </tr>
         <tr>
        <td>4</td>
        <td></td>
        <td>B.A. Hons. in Urdu</td>
      
      </tr>
         <tr>
        <td>5</td>
        <td>&nbsp;</td>
        <td>B.A. Hons. in Santhali</td>
      
      </tr>
         <tr>
        <td>6</td>
        <td>&nbsp;</td>
        <td>B.A. Hons. in Maithili</td>
      
      </tr>
         <tr>
        <td>7</td>
        <td>SOCIAL SCIENCES	 </td>
        <td>B.A. Hons. in History</td>
      
      </tr>
         <tr>
        <td>8</td>
        <td></td>
        <td>B.A. Hons. in Political Science</td>
      
      </tr>
         <tr>
        <td>9</td>
        <td></td>
        <td>B.A. Hons. in Economics</td>
      
      </tr>
         <tr>
        <td>10</td>
        <td></td>
        <td>B.A. Hons. in Psychology</td>
      
      </tr>
        
         <tr>
        <td>11</td>
        <td></td>
        <td>B.A. Hons. in Philosophy</td>
      
      </tr>
         <tr>
        <td>12</td>
        <td></td>
        <td>B.A. Hons. in Geography</td>
      
      </tr>
         <tr>
        <td>13</td>
        <td></td>
        <td>B.A. Hons. in Sociology</td>
      
      </tr>
         <tr>
        <td>14</td>
        <td>&nbsp;</td>
        <td>
               B.A. Hons. in Home Science</td>
      
      </tr>
         <tr>
        <td>15</td>
        <td>SCIENCE</td>
        <td>B.Sc. Hons. in Physics</td>
      
      </tr>
         <tr>
        <td>16</td>
        <td></td>
        <td>B.Sc. Hons. in Chemistry</td>
      
      </tr>
         <tr>
        <td>17</td>
        <td></td>
        <td>B.Sc. Hons. in Botany</td>
      
      </tr>
         <tr>
        <td>18</td>
        <td></td>
        <td>B.Sc. Hons. in Zoology</td>
      
      </tr>
         <tr>
        <td>19</td>
        <td></td>
        <td>B.Sc. in Mathematics</td>
      
      </tr>
         <tr>
        <td>20</td>
        <td></td>
        <td>B.Sc. Hons. in Geology</td>
      </tr>
         <tr>
        <td>21</td>
        <td>Commerce</td>
        <td>Bachelor in Commerce (B.com)</td>
      </tr>
    </tbody>
  </table>
                    </div>
                  <h3 style="color:#205495;">B. Post Graduate Degree Course (2 Years)</h3>
                <div class="row table-responsive">
                    <table class="table">
    <thead>
      <tr>
        <th>Sl.No.</th>
        <th>Name of Courses</th>
       </tr>
    </thead>
    <tbody>
      <tr>
        <th class="auto-style1">22</th>
        <th class="auto-style1">M.A in History</th>
       </tr>
      <tr>
        <th class="auto-style1">23</th>
        <th class="auto-style1">M.A in Political Science</th>
       </tr>
      <tr>
        <th class="auto-style1">24</th>
        <th class="auto-style1">M.A in Economics</th>
       </tr>
      <tr>
        <th class="auto-style1">25</th>
        <th class="auto-style1">M.A in Psychology</th>
       </tr>
         <tr>
        <th class="auto-style1">26</th>
        <th class="auto-style1">M.A in Philosophy</th>
       </tr>
         <tr>
        <th class="auto-style1">27</th>
        <th class="auto-style1">M.A in Hindi</th>
       </tr>
         <tr>
        <th class="auto-style1">28</th>
        <th class="auto-style1">M.A in English</th>
       </tr>
         <tr>
        <th class="auto-style1">29</th>
        <th class="auto-style1">M.A in Urdu</th>
       </tr>
         <tr>
        <th class="auto-style1">30</th>
        <th class="auto-style1">M.A in Santhali</th>
       </tr>
         <tr>
        <th class="auto-style1">31</th>
        <th class="auto-style1">M.sc. in Physics</th>
       </tr>
         <tr>
        <th class="auto-style1">32</th>
        <th class="auto-style1">M.sc. in Chemistry</th>
       </tr>
         <tr>
        <th class="auto-style1">33</th>
        <th class="auto-style1">M.sc. in Botany</th>
       </tr>
         <tr>
        <th class="auto-style1">34</th>
        <th class="auto-style1">M.sc. in Zoology</th>
       </tr>
         <tr>
        <th class="auto-style1">35</th>
        <th class="auto-style1">M.sc. in Mathematics</th>
       </tr>
         <tr>
        <th class="auto-style1">36</th>
        <th class="auto-style1">M.sc. in Geology</th>
       </tr>
        </tbody>
        </table>    
            </div>
                  <h3 style="color:#205495;">C. Professional Degree Courses</h3>
                <div class="row table-responsive">
                    <table class="table">
    <thead>
      <tr>
        <th>Sl.No.</th>
        <th>Name of Courses</th>
       </tr>
    </thead>
    <tbody>
      <tr>
        <th class="auto-style1">37</th>
        <th class="auto-style1">Bachelor of Education (B.Ed.) – 2 Years</th>
       </tr>
      <tr>
        <th class="auto-style1">38</th>
        <th class="auto-style1">Bachelor of Computer Applications (BCA) – 3 Years</th>
       </tr>
      <tr>
        <th class="auto-style1">39</th>
        <th class="auto-style1">Bachelor of Library and Information Science – 1 Year</th>
       </tr>
      <tr>
        <th class="auto-style1">40</th>
        <th class="auto-style1">Bachelor of Business Administration (BBA) – 3 Years</th>
       </tr>
        
        </tbody>
        </table>    
            </div>
                   <h3 style="color:#205495;">D. Diploma /Certificate Courses</h3>
                <div class="row table-responsive">
                    <table class="table">
    <thead>
      <tr>
        <th>Sl.No.</th>
        <th>Name of Courses</th>
       </tr>
    </thead>
    <tbody>
      <tr>
        <td>41</td>
        <td>Advance Diploma in Computer Application (ADCA)- 1 Year</td>
     </tr>
      <tr>
        <td>42</td>
        <td>Diploma in Computer Application (DCA) – 6 Months</td>
     </tr>
      <tr>
        <td>43</td>
        <td>Diploma in Desktop Publication (DTP) – 6 </td>
     </tr>
      <tr>
        <td>44</td>
        <td>Certificate Course in Computer Basic (CCCB) – 3 Months</td>
     </tr>
      <tr>
        <td>45</td>
        <td>Certificate Course in MS-Office Package(CCMSO) – 3 Months</td>
     </tr>
      <tr>
        <td>46</td>
        <td>certificate Course in Basic Internet Technology (CCBIT) – 3 Months</td>
     </tr>
      </tbody>
        </table>    
            </div>
                 <h3 style="color:#205495;">E. Skills Developments Programmes</h3>
                <p style="color:#205495;">&nbsp;</p>
                <p style="color:#205495;">&nbsp;</p>
            </div>
              </div>
              </div>
         </main>
   
    <?php
include 'footer.php';
?>