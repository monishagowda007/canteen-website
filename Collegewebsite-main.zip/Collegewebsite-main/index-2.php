<?php
include 'header.php';
?>
    
    <!--====== HEADER PART ENDS ======-->
   
    <!--====== SLIDER PART START ======-->
<main class="wrapper">
<div class="theme-padding">
<div class="container">
 <!-- Main Content Row -->
<div class="row">
<!-- Content -->
<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 ">
 <!-- Gallery Widget -->
<div class="post-widget">
<div class="banner-slider">
 <!-- slider main slides -->
 <div id="ninja-slider" class="ninja-slider">
  <div class="slider-inner">
 <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/slider/b.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slider/b.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slider/b.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>                                                           
<div class="fs-icon" title="Expand/Close"></div>
 </div>
 </div>
<!-- slider main slides -->
 <!-- Banner Thumnail -->
<!-- Banner Thumnail -->
</div>
  </div>
<!-- Gallery Widget -->
<br><br>
 <!-- list posts -->
 <div class="post-widget">
<!-- Main Heading -->
<div class="alert alert-dark" role="alert">
<h2>Principal's - Desk</h2>
</div>
                            <!-- List Post -->
<div class="p-30 light-shadow white-bg">
<ul class="list-posts">
<li class="row no-gutters">
<div class="col-sm-4 col-xs-12">
 <div class="post-thumb">
 </div>
  <d>
<div class="card item-card card-block">
<img src="http://manage.sahibganjcollege.in/assets/images/faculty/Img_10ee031299414dfaaba396d091295571_Camp_02_Mar_2021_07_22_43_AM_Media_70.jpeg" alt="">
 <h5 class="card-title  mt-3 mb-3">Dr. Rahul Kumar Santosh</h5>
 <p class="card-text">Principal</p> 
  </div>
 </div>
 <div class="col-sm-8 col-xs-12" >
<div style="  margin-left: 30px">
 <p >
 <h5 style="color:black;">Vision:</h5>
 <p>Sahibganj college, Sahibganj, Dist.-Sahibganj, State-Jharkhand has a very clear vision to impart quality education to the students of the backward area by inculcating  positive behavioral attitude with social commitment and to produce good graduate attributes by introducing latest teaching learning practices.</p>
 <br />
<h5 style="color:black;">Mission:</h5>
<p>To facilitate latest teaching learning tools in the class rooms. To motivate the faculty members to enrich their intellectual knowledge through research and to share their knowledge with their mentees. To enrich themselves through latest teaching tools. To motivate the students to engage in social activities and to fit themselves for better employment.</p>
 <br />
  <h5 style="color:black;">Objectives :</h5>
 <p>The objective is to implement the mission followed by the vision in a time bound process. To introduce innovative decision making policy by the faculty members to take their on decision for the benefit of the institution as a whole. Vision, Mission and Objective are communicated to the students, teachers, staff and other stakeholders through college website and disseminated in class rooms, library, principal room and laboratory.  </p>
  </div>  </div> </li> </ul></div> </div> </div>
         <!-- Content -->
<div class="col-lg-3 col-md-3 col-xs-12 custom-re">
<div class="row">
<aside class="side-bar grid">
 <div class="grid-item col-lg-12 col-md-12 col-sm-4 col-xs-6 r-full-width">
  <div class="widget">
 <ul class="aside-social">
 <li class="alert alert-warning" role="alert">
 <a href="log/index.php"  style="color: black; font-size: 10px; font-weight: bold;">Class 11th & 12th Online Admission</a>                                         
</li>           
</ul>
 </div>
</div>
  <div class="grid-item col-lg-12 col-md-12 col-sm-4 col-xs-6 r-full-width">
 <div class="widget">
<h3  class="p-2 bg-info text-light">Important Link</h3>
 <ul class="categories-widget">                                      
 <li><a target="_blank" href='http://manage.sahibganjcollege.in/assets/images/Link/Link2ab167627f1b44cdbaa129c28580c38c_Camp_08_Aug_2021_09_04_05_AM_Media_123.jpg'>
 <p style="margin: 10px;"><i style="margin-right: 10px;" class="fa fa-arrow-right" aria-hidden="true"></i> Download  Intermediate Admission Notice Year-2021</p>
</a></li>
 <li><a target="_blank" href='javascript:;'>
 <p class="p-2 bg-light text-success" style="margin: 10px;"><i style="margin-right: 10px;" class="fa fa-arrow-right" ></i>इंटरमीडिएट 11वीं कक्षा सत्र (2021-23) में नामांकन हेतु आवेदन एवं इंटरमीडिएट 12वीं कक्षा सत्र (2020-22) में नामांकन लेने वाले छात्र/छात्राओं एवं अभिभावकों को सूचित किया जाता है कि  वैश्विक महामारी करोना को मद्देनजर रखते हुए साहिबगंज महाविद्यालय प्रशासन द्वारा ऑनलाइन माध्यम से 11वीं कक्षा के लिए आवेदन एवं 12वीं कक्षा में 
  नामांकन की व्यवस्था की गई है I जिससे जो छात्र जहां है वहीं से अपना आवेदन एवं अपना नामांकन कर सकेंगे I इसके लिए उन्हें साहिबगंज महाविद्यालय, साहिबगंज के वेबसाइट  www.sahibganjcollege.in पर दिए गए लिंक से Login करना होगा I 11वीं कक्षा में आवेदन करने की तिथि 10 अगस्त 2021 से 31 अगस्त 2021 तक निर्धारित की गई है 
 </a></li>                                             
  </ul>
 </div>
  </div>
 <div class="grid-item col-lg-12 col-md-12 col-sm-4 col-xs-6 r-full-width">
<div class="widget">
<ul class="aside-social">
<li class="pi" style="width: 100%;">
 <a href="https://sahibganjcollege.in/documents/ssr2016.pdf" class="p-3 mb-2 bg-danger text-white" ><i class="fa fa-cloud-download"></i>&nbsp;&nbsp; SSR For Sahibganj College</a>
</li>
  </ul>
  </div>
 </div>
                              
 <div class="grid-item col-lg-12 col-md-12 col-sm-4 col-xs-6 r-full-width">
 <div class="widget">
 <ul class="aside-social">
<li class="p-3 mb-2 bg-success text-light" style="width: 100%; font-size: 14px; color: black; ">
  <a  style=" color: white; " href="gallery.php"><i class="fa fa-picture-o"></i>&nbsp;&nbsp; Gallery</a>
  </li>
</ul>
</div>
</div>
 <div class="grid-item col-lg-12 col-md-12 col-sm-4 col-xs-6 r-full-width">
<div class="widget">
<h3 class="p-2 bg-info text-light">Notice Board</h3>
<ul class="categories-widget" style="margin: 20px;">
<marquee behavior="scroll" direction="up" scrollamount="4" height="285px">
                                                
<li><a target="_blank" href='https://sahibganjcollege.in/documents/Intermedaite%20Admission-Notice-For-11th-&-12th-Year-2021.pdf'>
<p style="text-align:justify;">INTERMEDIATE ADMISSION NOTICE FOR YEAR - 2021 SAHIBGANJ COLLEGE , SAHIBGANJ</p>
 </a></li>
 <li><a target="_blank" href='javascript:;'>
 <p style="text-align:justify;">Admission Notice  इंटरमीडिएट 11वीं कक्षा सत्र (2021-23) में नामांकन हेतु आवेदन एवं इंटरमीडिएट 12वीं कक्षा सत्र (2020-22) में नामांकन लेने वाले छात्र/छात्राओं एवं अभिभावकों को सूचित किया जाता है कि  वैश्विक महामारी करोना को मद्देनजर रखते हुए साहिबगंज महाविद्यालय प्रशासन द्वारा ऑनलाइन माध्यम से 11वीं कक्षा के लिए आवेदन एवं 12वीं कक्षा में नामांकन की व्यवस्था की गई है I जिससे जो छात्र जहां है वहीं से अपना आवेदन एवं अपना नामांकन कर सकेंगे I इसके लिए उन्हें साहिबगंज महाविद्यालय, साहिबगंज के वेबसाइट www.sahibganjcollege.in पर दिए गए लिंक से Login करना होगा I 11वीं कक्षा में आवेदन करने की तिथि 10 अगस्त 2021 से 31 अगस्त 2021 तक निर्धारित की गई है  एवं 12वीं कक्षा में नामांकन के लिए 10 अगस्त से 2021 से 20 अगस्त 2021  तक निर्धारित की गई है I  डॉ राहुल कुमार संतोष , प्राचार्य  ,साहिबगंज महाविद्यालय साहिबगंज</p>
                                                   
  </a></li>   
</marquee>
</ul>
</div>
</div>
</div>                              
 </aside>
  </div>
    </div>
    </div>
  </div>
    </div>
    </main>
    <?php
    include 'footer.php';
    ?>
