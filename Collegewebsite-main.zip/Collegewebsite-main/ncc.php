<?php 
include 'header.php'
 ?>

<!-- Main Content -->
    <main class="main-wrap">
        <div class="theme-padding">
            <div class="container">

                <div class="row mb-30">

                    <!-- contact holder -->
                    <div class="col-md-12">

                        <!-- Heading -->
                         <nav class="navbar navbar-light bg-warning">
        <a class="navbar-brand" >
          NCC - National Cadet Corps
      </a>
    </nav> <br><br><br>
                        
                       

                        <div>
                            <p>National Cadet Core was established in the Sahibganj College in the year 2006. The unit for Boys and girl cadets are in operation in which about hundred students are enrolled.</p>
                           <p>The main activities include training of Cadets for A, B and C grade Certification and the students has been awarded Certificates for NCC achievements.</p>
                            <p>Awards- Vishal Prasad B&S/SD/11/13033 Unit 36 Jharkhand and B N NCC participated in Republic Day Camp and Prime Minister’s Rally at New Delhi as RD March &Certificate of NCC.</p>
                            <p>During 2011-2013 19NCC Cadets were awarded C certificate and 4 Cadets were awarded B certificate.</p>
                            <p>In 2012-14 4 Cadets were awarded C certificate where as 13 candidate were awarded B grade.</p>
                            <p>The NCC Cadets of Sahibganj College are regular participants in Republic Day and Independence Day Function at district HQ and form a part of Guard of Honor Contingent.</p>
                        </div>

                    </div>
                </div>


            </div>
        </div>
    </main>
    <!-- main content -->




 <?php 
include 'footer.php'
 ?>