<?php 
include 'header.php'
?>
<!-- Main Content -->
    <main style="background-color: #ffed4b">
        <div class="theme-padding">
            <div class="container">

                <div class="row mb-30">

                    <!-- contact holder -->
                    <div class="col-md-12">

                        <!-- Heading -->
                        <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand"style="color: white">
          NSS - National Service Scheme
      </a>
    </nav><br><br><br> <br><br>

                        
                            

                        <div class="contact-wrap">
                            <p style="font-weight: bold;">Eight NSS volunteers of this College viz. Sabina Tudu , Shanti Soren , Bakala , Susama Tudu , Panchm Kumar Mandal , Om Prakash Mandal ,Pappu Kumar Tigga , Durga Mandal participated in National Adventure camp 2013.</p>
                            <p style="font-weight: bold;">Two NSS volunteers Om Prakash Bakla and Sohagini Marandi also attended Mega camp 2013 from 13 Dec to 24 Dec which was organized by Tezpur University ,Tezpur (Assam).</p>
                            <p style="font-weight: bold;">Two NSS volunteers viz. Kalyani Kumari and santosh Kumar Mandal of this College also participated Republic day Parade 2014.</p>
                            <p style="font-weight: bold;">An awareness for Anti Ragging program was also organized by NSS volunteers of this College year 2014.</p>
                            <p style="font-weight: bold;">Plantation programme was also organized by NSS volunteers time to time.</p>
                            <p style="font-weight: bold;">International Women’s Day was also organized by under the banner of NSS.</p>
                            <p style="font-weight: bold;">International Environmental Day was also organized on 5th July 2013,2014,2015 in collaboration with District Forest Department.</p>
                            <p style="font-weight: bold;">The performance of NSS volunteers of this College has always remained encouraging. Seven times blood donation camp were organized by NSS volunteers of this college.Following NSS volunteers donated blood on 2nd February 2015.
                                <ol style="font-weight: bold;">
                                    <li>Brajesh Kumar</li>
                                    <li>Santosh Kumar Mandal</li>
                                    <li>Aniket kumar Singh</li>
                                    <li>Pawan kumar yadav</li>
                                    <li>Agisten Besera</li>
                                    <li>Jiten Jai Bardence Owraw</li>
                                    <li>Nikki Kumari</li>
                                </ol>
                            </p>
                            <p style="font-weight: bold;">A programme against Drug Addiction was also organized by NSS on the 26th June 2015.</p>
                            <p style="font-weight: bold;">Aditya Kumar Yadav a NSS volunteer attended Pre Republic day Parade 2015.</p>
                            <p style="font-weight: bold;">International Voters awareness programme was also organized in collaboration with District Administration in the College in year 2014,2015,2016 on 25th January .</p>
                            <p style="font-weight: bold;">Kalyani Kumari a NSS volunteer in this College has won 2nd Prize in National Speech competition held on January 2016.She was also awarded a cash of Rs. 1 Lac by Nehru Youth Centre at New Delhi.</p>
                            <p style="font-weight: bold;">A special camp “Clean India” was organized by NSS Volunteers between 29-12-2015 to 04-01-2016 at Bari Panchagarh.</p>
                        </div>

                    </div>
                </div>


            </div>
        </div>
    </main>
    <!-- main content -->






 <?php 
include 'footer.php'

 ?>