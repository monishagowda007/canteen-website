<?php 
include 'header.php'
 ?>
<a class="btn btn-primary" href="galleryphoto.php" role="button">Add Gallery Photo</a>
<a class="btn btn-primary" href="staffedit.php" role="button">Add Staff Photo</a>
<a class="btn btn-primary" href="reg.php" role="button">Add Faculty Photo</a>
 <br><br><br>

 <?php 
include 'footer.php'
 ?>